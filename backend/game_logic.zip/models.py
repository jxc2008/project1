import os
from pymongo import MongoClient

# Fetch the MongoDB URI from an environment variable
uri = os.getenv("MONGODB_URI", "mongodb://localhost:27017/")

# Initialize MongoDB client
client = MongoClient(uri)

# Define database and collection
db = client['quant_trading_game']
rooms_collection = db['rooms']
